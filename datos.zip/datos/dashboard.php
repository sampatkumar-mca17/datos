<?php
	include_once "includes/check_access.php";
	include_once "includes/header.php";
	include_once "includes/sidebar.php";
?>
	<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
          WELCOME
          </h1>
          <ol class="breadcrumb">
            <li class="active"><i class="fa fa-dashboard"></i> Home</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
         
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<?php
	include_once "includes/footer.php";
?>
<script>
  $(document).ready(function(){
    get_domain_count();
    get_provider_count();
    get_server_count();
    get_ftp_count();
    get_db_count();
    get_acc_count();
    
  });
   $(document).ready(function(){
    get_status_count();
   });
</script>