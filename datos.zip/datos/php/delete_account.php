<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();

			$id = mysqli_real_escape_string($link, test_input($_POST['id']));

			$query = "DELETE FROM `provider_account_tbl` WHERE `id` = ".$id;
			mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_affected_rows($link)){
				$response['status'] = 200;
				$response['title'] = "Account deleted.";
				$response['msg'] = "Provider account deleted successfully.";
			}else{
				$response['status'] = 201;
				$response['title'] = "Failed.";
				$response['msg'] = "Unable to delete the account, please try again.";
			}
			echo json_encode($response);
		}
	}
?>