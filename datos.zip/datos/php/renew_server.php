<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();

			$id = mysqli_real_escape_string($link, test_input($_POST['id']));
			$no = mysqli_real_escape_string($link, test_input($_POST['no']));

			// get the last renewal date
			$get_last_date = "SELECT `renewal_date` FROM `server_tbl` WHERE `id` = ".$id;
			$lrd = mysqli_query($link, $get_last_date) or die("Error: ".mysqli_error($link));
			$r = mysqli_fetch_assoc($lrd);

			$new_renewal =  date('Y-m-d', strtotime('+'.$no.' year', strtotime($r['renewal_date'])));
			
			// update the new renewal date
			$query = "UPDATE `server_tbl` SET `renewal_date` = '".$new_renewal."' WHERE `id` = ".$id;

			mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_affected_rows($link) > 0){
				$response['status'] = 200;
				$response['title'] = "Server Renewed.";
				$response['msg'] = "Server renewal date updated successfully.";
			}else{
				$response['status'] = 201;
				$response['title'] = "Renewal Failed.";
				$response['msg'] = "Server renewal failed, please try again.";	
			}
			echo json_encode($response);
		}
	}
?>