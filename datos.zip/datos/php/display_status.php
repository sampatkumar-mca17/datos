<?php
	include_once "../includes/db_connection.php";
 include_once "../includes/db_connection.php";

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        if($_POST['_token'] == md5(105)){
            $response = array();

            $status_count = "SELECT * FROM `project_tbl`";
            $a = mysqli_query($link, $status_count) or die('Error: '.mysqli_error($link));

            $sc = mysqli_fetch_assoc($a);
      

            $response['status'] = 200;
            $response['scnt'] = $sc['status'];
            

            echo json_encode($response);
        }
    }
?>