<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();

			$id = mysqli_real_escape_string($link, test_input($_POST['id']));
			$inms = mysqli_real_escape_string($link, test_input($_POST['inms']));
			$outms = mysqli_real_escape_string($link, test_input($_POST['outms']));

			$ms = array($inms, $outms);

			$query = "UPDATE `server_tbl` SET `email_server` = '".json_encode($ms)."' WHERE `id` = ".$id;
			
			// echo $query;
			mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_affected_rows($link) > 0){
				$response['status'] = 200;
				$response['title'] = "Mail Server Updated.";
				$response['msg'] = "Mail Servers updated successfully.";
			}else{
				$response['status'] = 201;
				$response['title'] = "Failed";
				$response['msg'] = "Unable to update the mail server, please try again.";
			}

			echo json_encode($response);
		}
	}
?>