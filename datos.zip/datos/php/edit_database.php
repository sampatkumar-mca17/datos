<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();

			$id = mysqli_real_escape_string($link, test_input($_POST['id']));
			$server = mysqli_real_escape_string($link, test_input($_POST['server']));
			$host = mysqli_real_escape_string($link, test_input($_POST['host']));
			$user = mysqli_real_escape_string($link, test_input($_POST['user']));
			$password = mysqli_real_escape_string($link, test_input($_POST['pass']));
			$db_name = mysqli_real_escape_string($link, test_input($_POST['db_name']));

			// check whether the database already exists
			$check_database = "SELECT * FROM `database_tbl` WHERE `server_id` = ".$server." AND `db_name` = '".$db_name."' AND `id` != ".$id;
			$result = mysqli_query($link, $check_database) or die("Error: ".mysqli_error($link));

			if(mysqli_num_rows($result) == 0){
				$query = "UPDATE `database_tbl` SET `server_id` = ".$server.", `host` = '".$host."', `user` = '".$user."', `password` = '".$password."', `db_name` = '".$db_name."' WHERE `id` = ".$id;
				mysqli_query($link, $query) or die("Error: ".mysqli_error($link));
				if(mysqli_affected_rows($link) > 0){
					$response['status'] = 200;
					$response['title'] = "Database Updated.";
					$response['msg'] = "Database updated successfully.";
				}else{
					$response['status'] = 201;
					$response['title'] = "Failed.";
					$response['msg'] = "Something went wrong, please try again.";
				}
			}else{
				$response['status'] = 201;
				$response['title'] = 'Duplicate Entry.';
				$response['msg'] = 'Entered database name already exists for the selected server.';
			}
			echo json_encode($response);
		}
	}
?>