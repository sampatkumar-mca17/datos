<?php

	include_once "../includes/db_connection.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();

			$id = $_POST['id'];

			$query = "DELETE FROM `domain_tbl` WHERE `id` = ".$id;

			mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_affected_rows($link) > 0){
				$response['status'] = 200;
				$response['title'] = "Domain Deleted";
				$response['msg'] = "Domain name deleted successfully.";
			}else{
				$response['status'] = 201;
				$response['title'] = "Failed";
				$response['msg'] = "Unable to delete the domain, please try again.";
			}
			echo json_encode($response);
		}
	}
?>