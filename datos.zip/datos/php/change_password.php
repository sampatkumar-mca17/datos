<?php
	session_start();
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$response = array();

		$old_pass = mysqli_real_escape_string($link, test_input($_POST['old_pass']));
		$new_pass = mysqli_real_escape_string($link, test_input($_POST['new_pass']));

		// check whether old password matches
		$check = "SELECT * FROM `admin_tbl` WHERE `id` = ".$_SESSION['user_id']." AND `password` = '".md5($old_pass)."'";
		$res = mysqli_query($link, $check) or die("Error: ".mysqli_error($link));

		if(mysqli_num_rows($res) == 1){
			$query = "UPDATE `admin_tbl` SET `password` = '".md5($new_pass)."' WHERE `id` = ".$_SESSION['user_id'];
			mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_affected_rows($link) > 0){
				$response['status'] = 200;
				$response['title'] = "Password Changed.";
				$response['msg'] = "Password changed successfully, try login in with new passwaord.";
			}else{
				$response['status'] = 201;
				$response['title'] = "Failed.";
				$response['msg'] = "Something went wrong, please try again.";
			}
		}else{
			$response['status'] = 201;
			$response['title'] = "Failed.";
			$response['msg'] = "Old password doesn't match.";
		}

		echo json_encode($response);
	}
?>