<?php 
session_start();
include_once "../includes/db_connection.php";
if($_SERVER['REQUEST_METHOD']=="POST")
{
	$stat=$_POST['stat'];
	$response=array();
	$store="SELECT * FROM `project_tbl`";
	$res=mysqli_query($link,$store);
	$row=mysqli_fetch_assoc($res);
		$_SESSION['status']=$row['status'];
	if($_SESSION['status']<$stat)
	{
		$celect="SELECT * FROM `project_tbl`";
		$exe=mysqli_query($link,$celect);
		if(mysqli_num_rows($exe)>0)
		{
		$trun="TRUNCATE `project_tbl`";
		$truncate=mysqli_query($link,$trun);
		}
		$query="INSERT INTO `project_tbl`(`status`) VALUES('".$stat."')";
		if(mysqli_query($link,$query))
	{
		$response['status']=200;
		
	}
	else
	{
		$response['status']=201;
		$response['msg']="Something Went Wrong";
	}
}
else
{
	$response['status']=201;
	$response['msg']="status cannot get lesser";
}
}
echo json_encode($response);
 ?>