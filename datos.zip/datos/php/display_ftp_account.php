<?php
	include_once "../includes/db_connection.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(105) == $_POST['_token']){
			$response = array();
			$ftp = array();

			$query = "SELECT s.cpanel_url, f.server_id, f.id, f.host, f.username as fuser, f.password, f.path, f.user_id, a.fullname 
					FROM `server_tbl` as s, `ftp_tbl` as f, `admin_tbl` as a
					WHERE f.server_id = s.id AND a.id = f.user_id";

			$result = mysqli_query($link, $query) or die("Error: ".mysqli_error($link));
			if(mysqli_num_rows($result) > 0){
				while($row = mysqli_fetch_assoc($result)){
					array_push($ftp, $row);
				}
				$response['status'] = 200;
				$response['ftp'] = $ftp;
			}else{
				$response['status'] = 201;
				$response['msg'] = "No records found in the system.";
			}
			echo json_encode($response);
		}
	}
?>