<?php
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){

			$response = array();

			$provider_acc = mysqli_real_escape_string($link, test_input($_POST['account']));
			$dns = mysqli_real_escape_string($link, test_input($_POST['domain']));
			$renewal = mysqli_real_escape_string($link, test_input($_POST['renewal']));
			$emails = $_POST['email'];
			$passwords = $_POST['password'];

			$email_accounts = array();
			if(count($emails) > 0){
				for($i = 0; $i < count($emails); $i++){
					array_push($email_accounts, array('email' => $emails[$i].'@'.$dns, 'password' => $passwords[$i]));
				}
			}

			// check whether the domain name already exists
			$check_domain = "SELECT * FROM `domain_tbl` WHERE `domain_name` = '".$dns."'";
			$result = mysqli_query($link, $check_domain) or die("Error: ".mysqli_error($link));
			if(mysqli_num_rows($result) == 0){
				$query = '';
				if(count($email_accounts) > 0){
					$query = "INSERT INTO `domain_tbl` (`pro_acc_id`, `domain_name`, `email_accounts`, `expiry_date`, `created_at`)
						VALUES (".$provider_acc.", '".$dns."', '".json_encode($email_accounts)."', '".date('Y-m-d', strtotime($renewal))."', '".date('Y-m-d H:i:s')."')";
				}else{
					$query = "INSERT INTO `domain_tbl` (`pro_acc_id`, `domain_name`, `expiry_date`, `created_at`)
						VALUES (".$provider_acc.", '".$dns."', '".date('Y-m-d', strtotime($renewal))."', '".date('Y-m-d H:i:s')."')";
				}
				mysqli_query($link, $query) or die("Error: ".mysqli_error($link));
				if(mysqli_affected_rows($link) > 0){
					$response['status'] = 200;
					$response['title'] = "Domain Name Added.";
					$response['msg'] = "Domain Name added successfully.";
				}else{
					$response['status'] = 201;
					$response['title'] = "Failed";
					$response['msg'] = "Something went wrong, please try agian.";
				}
			}else{
				$response['status'] = 201;
				$response['title'] = "Duplicate Entry";
				$response['msg'] = "Entered domain name already exists in the system.";
			}
			echo json_encode($response);
		}
	}
?>