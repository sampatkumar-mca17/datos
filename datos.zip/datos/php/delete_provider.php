<?php

	include_once "../includes/db_connection.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();

			$id = $_POST['id'];

			$query = "DELETE FROM `provider_tbl` WHERE `id` = ".$id;

			mysqli_query($link, $query) or die("Error: ".mysqli_query($link));
			if(mysqli_affected_rows($link) > 0){
				$response['status'] = 200;
				$response['title'] = "Provider Deleted.";
				$response['msg'] = "Provider information deleted successfully.";
			}else{
				$response['status'] = 201;
				$response['title'] = "Failed.";
				$response['msg'] = "Unable to delete the provider information, please try again.";
			}
			echo json_encode($response);
		}
	}
?>