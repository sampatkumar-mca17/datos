<?php
	
	include_once "../includes/db_connection.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(105) == $_POST['_token']){
			$response = array();
			$db = array();

			$query = "SELECT s.username, s.cpanel_url, d.id, d.server_id, d.host, d.user, d.password, d.db_name
				FROM `database_tbl` as d, server_tbl as s 
				WHERE s.id = d.server_id";
			$result = mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_num_rows($result) > 0){
				while($row = mysqli_fetch_assoc($result)){
					array_push($db, $row);
				}
				$response['status'] = 200;
				$response['db'] = $db;
			}else{
				$response['status'] = 201;
				$response['msg'] = "No databases added to the system yet.";
			}
			echo json_encode($response);
		}
	}

?>