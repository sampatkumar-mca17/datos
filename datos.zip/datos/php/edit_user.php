<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){

			$response = array();

			$user_id = $_POST['user_id'];
			$full_name = mysqli_real_escape_string($link, test_input($_POST['fullname']));
			$email = mysqli_real_escape_string($link, test_input($_POST['email']));
			$mobile = mysqli_real_escape_string($link, test_input($_POST['mobile']));
			$is_admin = test_input($_POST['is_admin']);

			$check_info = "SELECT * FROM `admin_tbl` WHERE (`id` <> ".$user_id." AND `email` = '".$email."') OR (`id` <> ".$user_id." AND `mobile` = '".$mobile."')";
			$result = mysqli_query($link, $check_info) or die('Error: '.mysqli_error($link));

			if(mysqli_num_rows($result) == 0){

				$query = "UPDATE `admin_tbl` SET `fullname` ='".$full_name."', `email` = '".$email."', `mobile` = '".$mobile."', `is_admin` = ".$is_admin." WHERE `id` = ".$user_id;

				if(mysqli_query($link, $query)){
					$response['status'] = 200;
					$response['title'] = 'Update Successful';
					$response['msg'] = 'Users information updated successfully.';
				}else{
					$response['status'] = 201;
					$response['title'] = 'Update Failed.';
					$response['msg'] = 'Unable to update the users information, please try again !';
				}
			}else{
				$response['status'] = 202;
				$response['title'] = 'Duplicate User';
				$response['msg'] = 'Mobile number or Email address already exist in the record.';
			}
			echo json_encode($response);
		}
	}
	
?>