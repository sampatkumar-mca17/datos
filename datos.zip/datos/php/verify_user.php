<?php
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$response = array();

		$type = $_POST['type'];
		$email = mysqli_real_escape_string($link, test_input($_POST['email']));
		$mobile = mysqli_real_escape_string($link, test_input($_POST['mobile']));

		// verify the user account
		$query = "SELECT * FROM `admin_tbl` WHERE `is_admin` = ".$type." AND `email` = '".$email."' AND `mobile` = '".$mobile."'";
		$result = mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

		if(mysqli_num_rows($result) == 1){
			$row = mysqli_fetch_assoc($result);

			$response['status'] = 200;
			$response['user_id'] = md5($row['id']);
		}else{
			$response['status'] = 201;
		}

		echo json_encode($response);
	}
?>