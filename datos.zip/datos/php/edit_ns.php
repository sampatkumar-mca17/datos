<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();

			$id = mysqli_real_escape_string($link, test_input($_POST['id']));
			$ns1 = mysqli_real_escape_string($link, test_input($_POST['ns1']));
			$ns2 = mysqli_real_escape_string($link, test_input($_POST['ns2']));

			$ns = array($ns1);
			if($ns2 != '')
				array_push($ns, $ns2);

			$query = "UPDATE `server_tbl` SET `name_server` = '".json_encode($ns)."' WHERE `id` = ".$id;
			
			// echo $query;
			mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_affected_rows($link) > 0){
				$response['status'] = 200;
				$response['title'] = "Name Server Updated.";
				$response['msg'] = "Name Servers updated successfully.";
			}else{
				$response['status'] = 201;
				$response['title'] = "Failed";
				$response['msg'] = "Unable to update the name server, please try again.";
			}

			echo json_encode($response);
		}
	}
?>