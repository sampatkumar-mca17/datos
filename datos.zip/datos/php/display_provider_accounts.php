<?php
	
	include_once "../includes/db_connection.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(105) == $_POST['_token']){
			
			$response = array();
			$accounts = array();

			$query = "SELECT p.provider_name as name, p.website_url as url, pa.id as id, pa.provider_id as pid, pa.username as uname, pa.password as pwd, pa.security_pin as pin 
				FROM `provider_account_tbl` as pa, `provider_tbl` as p 
				WHERE pa.provider_id = p.id";

			$result = mysqli_query($link, $query) or die('Error: '.mysqli_error($link));

			if(mysqli_num_rows($result) > 0){
				while($row = mysqli_fetch_assoc($result)){
					array_push($accounts, $row);
				}

				$response['status'] = 200;
				$response['account'] = $accounts;
			}else{
				$response['status'] = 201;
				$response['msg'] = 'No account info added yet.';
			}
			echo json_encode($response);
		}
	}
?>