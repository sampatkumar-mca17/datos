<?php
    include_once "../includes/db_connection.php";

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        if($_POST['_token'] == md5(105)){
            $response = array();

            $admin_count = "SELECT COUNT(*) as acnt FROM `admin_tbl` WHERE `is_admin` = 1";
            $team_count = "SELECT COUNT(*) as tcnt FROM `admin_tbl` WHERE `is_admin` = 0";

            $a = mysqli_query($link, $admin_count) or die('Error: '.mysqli_error($link));
            $t = mysqli_query($link, $team_count) or die('Error: '.mysqli_error($link));

            $ad = mysqli_fetch_assoc($a);
            $tm = mysqli_fetch_assoc($t);

            $response['status'] = 200;
            $response['acnt'] = $ad['acnt'];
            $response['tcnt'] = $tm['tcnt'];

            echo json_encode($response);
        }
    }
?>