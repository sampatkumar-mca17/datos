<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();

			$account = mysqli_real_escape_string($link, test_input($_POST['account']));
			$ip = mysqli_real_escape_string($link, test_input($_POST['ip']));
			$url = mysqli_real_escape_string($link, test_input($_POST['url']));
			$username = mysqli_real_escape_string($link, test_input($_POST['username']));
			$password = mysqli_real_escape_string($link, test_input($_POST['password']));
			$ns1 = mysqli_real_escape_string($link, test_input($_POST['ns1']));
			$ns2 = mysqli_real_escape_string($link, test_input($_POST['ns2']));
			$in_mail = mysqli_real_escape_string($link, test_input($_POST['in_mail']));
			$out_mail = mysqli_real_escape_string($link, test_input($_POST['out_mail']));
			$renewal = mysqli_real_escape_string($link, test_input($_POST['renewal']));

			// check whether the server already exist
			$check_server = "SELECT * FROM `server_tbl` WHERE `username` = '".$username."'";
			$result = mysqli_query($link, $check_server) or die("Error: ".mysqli_error($link));

			if(mysqli_num_rows($result) == 0){
				$ns = array($ns1);
				if($ns2 != '')
					array_push($ns, $ns2);

				$mail_server = array($in_mail, $out_mail);

				$query = "INSERT INTO `server_tbl` (`pro_acc_id`, `server_ip`, `cpanel_url`, `username`, `password`, `email_server`, `name_server`, `created_at`, `renewal_date`)
					VALUES(".$account.", '".$ip."', '".$url."', '".$username."', '".$password."', '".json_encode($mail_server)."', '".json_encode($ns)."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d', strtotime($renewal))."')";

				// echo $query;
				mysqli_query($link, $query) or die('Error: '.mysqli_error($link));

				if(mysqli_affected_rows($link) > 0){
					$response['status'] = 200;
					$response['title'] = "Server Added";
					$response['msg'] = "New server information added successfully.";
				}else{
					$response['status'] = 201;
					$response['title'] = "Unable to add";
					$response['msg'] = "Something went wrong, please try again.";
				}
			}else{
				$response['status'] = 201;
				$response['title'] = "Duplicate Entry";
				$response['msg'] = "Server with same username already exists.";
			}
			echo json_encode($response);
		}
	}
?>