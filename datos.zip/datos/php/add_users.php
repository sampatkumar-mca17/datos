<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){

			$response = array();


			$full_name = mysqli_real_escape_string($link, test_input($_POST['fullname']));
			$email = mysqli_real_escape_string($link, test_input($_POST['email']));
			$mobile = mysqli_real_escape_string($link, test_input($_POST['mobile']));
			$is_admin = test_input($_POST['is_admin']);

			$check_info = "SELECT * FROM `admin_tbl` WHERE `email` = '".$email."' OR `mobile` ='".$mobile."'";
			$result = mysqli_query($link, $check_info) or die('Error: '.mysqli_error($link));

			if(mysqli_num_rows($result) == 0){
				$initial_password = generateRandomString();

				$query = "INSERT INTO `admin_tbl` (`fullname`, `email`, `mobile`, `password`, `initial_password`, `is_admin`, `ip_addr`, `created_at`) 
					VALUES('".$full_name."', '".$email."', '".$mobile."', '".md5($initial_password)."', '".$initial_password."', ".$is_admin.", '".$_SERVER['REMOTE_ADDR']."', '".date('Y-m-d H:i:s')."')";

				if(mysqli_query($link, $query)){
					$response['status'] = 200;
					$response['title'] = 'User Registered.';
					$response['msg'] = 'New user added successfully !';
				}else{
					$response['status'] = 201;
					$response['title'] = 'Registration Failed.';
					$response['msg'] = 'Unable to register the new user, please try again !';
				}
			}else{
				$response['status'] = 202;
				$response['title'] = 'Duplicate User';
				$response['msg'] = 'Mobile number or Email address already exist in the record.';
			}
			echo json_encode($response);
		}
	}
	

	
	

	// Random password generator
	function generateRandomString() {
		$length = 8;
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@#_';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}
?>