<?php
	
	include_once "../includes/db_connection.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(105) == $_POST['_token']){
			$response = array();
			$server = array();

			$query = "SELECT s.id, s.server_ip, s.cpanel_url, s.username as cpuser, s.password, s.email_server, s.name_server, s.is_active, s.renewal_date, pa.username, p.provider_name, p.website_url, s.pro_acc_id 
				FROM `server_tbl` as s, `provider_account_tbl` as pa, `provider_tbl` as p 
				WHERE s.pro_acc_id = pa.id AND pa.provider_id = p.id";

			$result = mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_num_rows($result) > 0){
				while($row = mysqli_fetch_assoc($result)){
					array_push($server, $row);
				}
				$response['status'] = 200;
				$response['server'] = $server;
			}else{
				$response['status'] = 201;
				$response['msg'] = "No servers available.";
			}
			echo json_encode($response);
		}
	}
?>