<?php
	
	include_once "../includes/db_connection.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			
			$response = array();
			$user_id = $_POST['user_id'];
			$new_pass = generateRandomString();
			$query = "UPDATE `admin_tbl` SET `password` = '".md5($new_pass)."', `initial_password` = '".$new_pass."' WHERE `id` = ".$user_id;

			mysqli_query($link, $query);

			if(mysqli_affected_rows($link) > 0){
				$response['status'] = 200;
				$response['title'] = 'Reset Successful';
				$response['msg'] = 'New password generated and reset successfully';
			}else{
				$response['status'] = 201;
				$response['title'] = 'Reset Failed';
				$response['msg'] = 'Password reset failed, please try again';
			}
		}
		echo json_encode($response);
	}


	// Random password generator
	function generateRandomString() {
		$length = 8;
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@#_';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}
?>