<?php
	session_start();

	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if(isset($_GET) && isset($_GET['status'])){
	    if($_GET['status'] == 'logout'){
            session_destroy();
            echo "<script>location.href='http://localhost/datos/index.php'</script>";
        }
    }

	if($_SERVER['REQUEST_METHOD'] == 'POST'){

		$response = array();

		$username = mysqli_real_escape_string($link, test_input($_POST['username']));
		$password = mysqli_real_escape_string($link, test_input($_POST['password']));

		$query = "SELECT * FROM `admin_tbl` 
				WHERE (`email` = '".$username."' AND `password` = '".md5($password)."') OR (`mobile` = '".$username."' AND `password` = '".md5($password)."')";


        $result = mysqli_query($link, $query) or die('Error: '.mysqli_error($link));

		if(mysqli_num_rows($result) == 1){
			$row = mysqli_fetch_assoc($result);

			if($row['is_active'] == 1){
				$_SESSION['login_status'] = 'login';
				$_SESSION['user'] = $row['fullname'];
				$_SESSION['user_id'] = $row['id'];
				$_SESSION['is_admin'] = $row['is_admin'];
				$_SESSION['period'] = date('d M Y', strtotime($row['created_at']));
				$response['status'] = 200;
			}else{
				$response['status'] = 201;
				$response['msg'] = 'Your account is inactive.';
			}
		}else{
			$response['status'] = 201;
			$response['msg'] = 'Incorrect username or password.';
		}

		echo json_encode($response);
	}
?>