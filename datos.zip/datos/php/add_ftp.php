<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();

			$server_id = mysqli_real_escape_string($link, test_input($_POST['server']));
			$host = mysqli_real_escape_string($link, test_input($_POST['host']));
			$username = mysqli_real_escape_string($link, test_input($_POST['username']));
			$password = mysqli_real_escape_string($link, test_input($_POST['password']));
			$path = mysqli_real_escape_string($link, test_input($_POST['path']));
			$user_id = mysqli_real_escape_string($link, test_input($_POST['user']));

			// check whether the username already already present in the system
			$check_username = "SELECT * FROM `ftp_tbl` WHERE `username` = '".$username."'";
			$result = mysqli_query($link, $check_username) or die("Error: ".mysqli_error($link));

			if(mysqli_num_rows($result) == 0){
				$query = "INSERT INTO `ftp_tbl` (`server_id`, `host`, `username`, `password`, `path`, `user_id`)
					VALUES (".$server_id.", '".$host."', '".$username."', '".$password."', '".$path."', ".$user_id.")";
				mysqli_query($link, $query) or die("Error: ".mysqli_error($link));
				if(mysqli_affected_rows($link) > 0){
					$response['status'] = 200;
					$response['title'] = "FTP Account Added.";
					$response['msg'] = "FTP Account added successfully, and available to use.";
				}else{
					$response['status'] = 201;
					$response['title'] = "Failed.";
					$response['msg'] = "Something went wrong, please try again.";
				}
			}else{
				$response['status'] = 201;
				$response['title'] = "Duplicate Entry.";
				$response['msg'] = "Entered FTP username already exists in the system.";
			}
			echo json_encode($response);
		}
	}
?>