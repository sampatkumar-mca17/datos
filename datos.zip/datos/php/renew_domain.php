<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();

			$id = mysqli_real_escape_string($link, test_input($_POST['id']));
			$no = mysqli_real_escape_string($link, test_input($_POST['no']));

			// get the last renewal date
			$get_last_date = "SELECT `expiry_date` FROM `domain_tbl` WHERE `id` = ".$id;
			$lrd = mysqli_query($link, $get_last_date) or die("Error: ".mysqli_error($link));
			$r = mysqli_fetch_assoc($lrd);

			$new_renewal =  date('Y-m-d', strtotime('+'.$no.' year', strtotime($r['expiry_date'])));
			
			// update the new renewal date
			$query = "UPDATE `domain_tbl` SET `expiry_date` = '".$new_renewal."' WHERE `id` = ".$id;

			mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_affected_rows($link) > 0){
				$response['status'] = 200;
				$response['title'] = "Domain Renewed.";
				$response['msg'] = "Domain renewal date updated successfully.";
			}else{
				$response['status'] = 201;
				$response['title'] = "Renewal Failed.";
				$response['msg'] = "Domain renewal failed, please try again.";	
			}
			echo json_encode($response);
		}
	}
?>