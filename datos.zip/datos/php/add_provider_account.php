<?php

	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();
			
			$pid = mysqli_real_escape_string($link, test_input($_POST['provider_id']));
			$username = mysqli_real_escape_string($link, test_input($_POST['username']));
			$password = mysqli_real_escape_string($link, test_input($_POST['password']));
			$pin = mysqli_real_escape_string($link, test_input($_POST['pin']));

			// check for duplicate entry
			// if there is same username entry for same provider then it is duplicate
			$check_acc_duplicate = "SELECT * FROM `provider_account_tbl` WHERE `provider_id` = ".$pid." AND `username` = '".$username."'";
			$result = mysqli_query($link, $check_acc_duplicate) or die('Error: '.mysqli_error($link));

			if(mysqli_num_rows($result) == 0){
				// Success and ready to insert
				$query = '';
				if($pin == ''){
					$query = "INSERT INTO `provider_account_tbl` (`provider_id`, `username`, `password`)
					VALUES (".$pid.", '".$username."', '".$password."')";
				}else{
					$query = "INSERT INTO `provider_account_tbl` (`provider_id`, `username`, `password`, `security_pin`)
					VALUES (".$pid.", '".$username."', '".$password."', '".$pin."')";
				}

				mysqli_query($link, $query) or die('Error: '.mysqli_error($link));
				if(mysqli_affected_rows($link) > 0){
					$response['status'] = 200;
					$response['title'] = 'Account added.';
					$response['msg'] = 'Provider account info added successfully.';
				}else{
					$response['status'] = 201;
					$response['title'] = 'Failed.';
					$response['msg'] = 'Unable to add the provider account, please try again.';
				}
			}else{
				$response['status'] = 201;
				$response['title'] = 'Duplicate entry';
				$response['msg'] = 'Same account detail already exists for the selected provider.';
			}
			echo json_encode($response);
		}
	}

?>