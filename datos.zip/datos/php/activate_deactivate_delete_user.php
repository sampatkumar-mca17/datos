<?php

	include_once "../includes/db_connection.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){

		if(md5(100) == $_POST['_token']){
			$response = array();
			$user_id = $_POST['user_id'];
			$operation = $_POST['operation'];
			
			$query = '';
			if($operation === 'deactivate'){
				// deactivating the user account
				$query = "UPDATE `admin_tbl` SET `is_active` = 0 WHERE `id` = $user_id";
			}else if($operation === 'activate'){
				// activating the user account
				$query = "UPDATE `admin_tbl` SET `is_active` = 1 WHERE `id` = $user_id";
			}else if($operation === 'delete'){
				// delete the user account
				$query = "DELETE FROM `admin_tbl` WHERE `id` = $user_id";
			}

			mysqli_query($link, $query);

			if(mysqli_affected_rows($link) > 0){
				if($operation === 'deactivate'){
					$response['status'] = 200;
					$response['title'] = 'Successfull';
					$response['msg'] = 'User deactivated successfully';
				}else if($operation === 'activate'){
					$response['status'] = 200;
					$response['title'] = 'Successfull';
					$response['msg'] = 'User activated successfully';	
				}else if($operation === 'delete'){
					$response['status'] = 200;
					$response['title'] = 'Successfull';
					$response['msg'] = 'User deleted successfully';
				}
			}else{
				if($operation === 'deactivate'){
					$response['status'] = 201;
					$response['title'] = 'Unsuccessfull';
					$response['msg'] = 'Unable to deactiva the user, please try again';
				}else if($operation === 'activate'){
					$response['status'] = 201;
					$response['title'] = 'Unsuccessfull';
					$response['msg'] = 'Unable to activate the user, please try again';	
				}else if($operation === 'delete'){
					$response['status'] = 201;
					$response['title'] = 'Unsuccessfull';
					$response['msg'] = 'Unable to delete the user, please try again';
				}
			}

			echo json_encode($response);
		}
	}
?>