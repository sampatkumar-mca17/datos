<?php
	include_once "../includes/db_connection.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(105) == $_POST['_token']){

			$response = array();
			$providers = array();

			$query = "SELECT * FROM `provider_tbl`";
			$result = mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_num_rows($result) > 0){
				while($row = mysqli_fetch_assoc($result))
				{
					$arr = array(
							'id' => $row['id'],
							'name' => strtoupper($row['provider_name']),
							'website' => $row['website_url'],
							'email' => json_decode($row['email']),
							'contact' => json_decode($row['contact'])
						);
					array_push($providers, $arr);
				}
				$response['status'] = 200;
				$response['provider'] = $providers;
			}else{
				$response['status'] = 201;
				$response['msg'] = "No providers added yet";
			}

			echo json_encode($response);
		}
	}
?>