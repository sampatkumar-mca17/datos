<?php
	
	include_once "../includes/check_access.php";
	include_once "../includes/db_connection.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(105) == $_POST['_token']){

			$response = array();
			$users = array();
			
			$query = "SELECT * FROM `admin_tbl` WHERE `id` <> ".$_SESSION['user_id']." ORDER BY `fullname` ASC";

			$result = mysqli_query($link, $query) or die('Error: '.mysqli_error($link));

			if(mysqli_num_rows($result) > 0){
				while($row = mysqli_fetch_assoc($result)){
					$arr = array(
							'id' => $row['id'],
							'fullname' => $row['fullname'],
							'email' => $row['email'],
							'mobile' => $row['mobile'],
							'created_at' => date('d/M/Y h:i a', strtotime($row['created_at'])),
							'ini_pass' => $row['initial_password'],
							'is_admin' => $row['is_admin'],
							'is_active' => $row['is_active']
						);
					array_push($users, $arr);
				}

				$response['status'] = 200;
				$response['users'] = $users;
				$response['user_type'] = $_SESSION['is_admin'];
			}else{
				$response['status'] = 201;
				$response['msg'] = "No other users have access to the system";
			}

			echo json_encode($response);
		}
	}
?>