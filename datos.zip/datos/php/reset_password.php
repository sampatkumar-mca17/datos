<?php
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$response = array();

		$new_pass = mysqli_real_escape_string($link, test_input($_POST['new_pass']));
		$user_id = $_POST['user_id'];

		$query = "UPDATE `admin_tbl` SET `password` = '".md5($new_pass)."' WHERE MD5(`id`) = '".$user_id."'";
		// echo $query;
		mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

		if(mysqli_affected_rows($link) > 0){
			$response['status'] = 200;
		}else{
			$response['status'] = 201;
		}
		
		echo json_encode($response);
	}
?>