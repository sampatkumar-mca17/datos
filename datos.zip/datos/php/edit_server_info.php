<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			
			$response = array();

			$id = $_POST['id'];
			$account = mysqli_real_escape_string($link, test_input($_POST['account']));
			$ip = mysqli_real_escape_string($link, test_input($_POST['ip']));
			$url = mysqli_real_escape_string($link, test_input($_POST['url']));
			$username = mysqli_real_escape_string($link, test_input($_POST['username']));
			$password = mysqli_real_escape_string($link, test_input($_POST['password']));

			// check whether the server already exist
			$check_server = "SELECT * FROM `server_tbl` WHERE `username` = '".$username."' AND `id` <> ".$id;
			$result = mysqli_query($link, $check_server) or die("Error: ".mysqli_error($link));

			if(mysqli_num_rows($result) == 0){

				$query = "UPDATE `server_tbl` SET `pro_acc_id` = ".$account.", `server_ip` = '".$ip."', `cpanel_url` = '".$url."', `username` = '".$username."', `password` = '".$password."' WHERE `id` = ".$id;
				mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

				if(mysqli_affected_rows($link) > 0){
					$response['status'] = 200;
					$response['title'] = "Server Updated";
					$response['msg'] = "Server Information Updated successfully.";
				}else{
					$response['status'] = 201;
					$response['title'] = "Update Failed.";
					$response['msg'] = "Something went wrong, or no change made.";
				}
			}else{
				$response['status'] = 201;
				$response['title'] = "Duplicate Entry";
				$response['msg'] = "Entered username already exists.";
			}
			echo json_encode($response);
		}
	}
?>