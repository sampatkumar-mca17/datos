<?php

	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();
			$pa_id = mysqli_real_escape_string($link, test_input($_POST['pa_id']));
			$pid = mysqli_real_escape_string($link, test_input($_POST['provider_id']));
			$username = mysqli_real_escape_string($link, test_input($_POST['username']));
			$password = mysqli_real_escape_string($link, test_input($_POST['password']));
			$pin = mysqli_real_escape_string($link, test_input($_POST['pin']));

			// check for duplicate entry
			// if there is same username entry for same provider then it is duplicate
			$check_acc_duplicate = "SELECT * FROM `provider_account_tbl` WHERE `id` != ".$pa_id." AND `provider_id` = ".$pid." AND `username` = '".$username."'";
			$result = mysqli_query($link, $check_acc_duplicate) or die('Error: '.mysqli_error($link));

			if(mysqli_num_rows($result) == 0){
				// Success and ready to insert
				$query = '';
				if($pin == ''){
					$query = "UPDATE `provider_account_tbl` SET `provider_id` = ".$pid.", `username` = '".$username."', `password` = '".$password."', `security_pin` = NULL WHERE `id` = ".$pa_id;
				}else{
					$query = "UPDATE `provider_account_tbl` SET `provider_id` = ".$pid.", `username` = '".$username."', `password` = '".$password."', `security_pin` = '".$pin."' WHERE `id` =".$pa_id;
				}
				// echo $query;

				mysqli_query($link, $query) or die('Error: '.mysqli_error($link));
				if(mysqli_affected_rows($link) > 0){
					$response['status'] = 200;
					$response['title'] = 'Account updated.';
					$response['msg'] = 'Provider account info updated successfully.';
				}else{
					$response['status'] = 201;
					$response['title'] = 'Failed.';
					$response['msg'] = 'Unable to update the provider account or you haven\'t made any change in the data.';
				}
			}else{
				$response['status'] = 201;
				$response['title'] = 'Duplicate entry';
				$response['msg'] = 'Same account detail already exists for the selected provider.';
			}
			echo json_encode($response);
		}
	}

?>