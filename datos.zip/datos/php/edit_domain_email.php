<?php
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$response = array();

			$index = $_POST['index'];
			$id = $_POST['id'];
			$email = mysqli_real_escape_string($link, test_input($_POST['new_email']));

			// get email json array
			$query = "SELECT `email_accounts` FROM `domain_tbl` WHERE `id` = ".$id;
			$result = mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			$row = mysqli_fetch_assoc($result);
			$emails = json_decode($row['email_accounts']);

			$emails[$index]->email = $email;

			// update
			$query = "UPDATE `domain_tbl` SET `email_accounts` = '".json_encode($emails)."' WHERE `id` = ".$id;
			mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_affected_rows($link) > 0){
				$response['status'] = 200;
				$response['title'] = "Email Updated";
				$response['msg'] = "New email updated successfully.";
			}else{
				$response['status'] = 201;
				$response['title'] = "Failed";
				$response['msg'] = "You have made no change in the inputs.";
			}
			echo json_encode($response);
		}
	}
?>