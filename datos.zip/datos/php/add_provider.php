<?php
	
	include_once "../includes/db_connection.php";
	include_once "../includes/test_input.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(100) == $_POST['_token']){
			$name = mysqli_real_escape_string($link, test_input($_POST['name']));
			$website = mysqli_real_escape_string($link, test_input($_POST['website']));		

			$emails = array();
			$contacts = array();

			if(isset($_POST['etype'])){
				$etype = $_POST['etype'];
				$email = $_POST['email'];
				for($i = 0; $i < count($etype); $i++){
					array_push($emails, array('etype' => $etype[$i], 'email' => $email[$i]));
				}
			}

			if(isset($_POST['ctype'])){
				$ctype = $_POST['ctype'];
				$contact = $_POST['contact'];
				for($i = 0; $i < count($ctype); $i++){
					array_push($contacts, array('ctype' => $ctype[$i], 'contact' => $contact[$i]));
				}
			}
			
			$query = "INSERT INTO `provider_tbl` (`provider_name`,`website_url`,`email`,`contact`)
				VALUES('".$name."', '".$website."', '".json_encode($emails)."', '".json_encode($contacts)."')";

			if(mysqli_query($link, $query)){
				$response['status'] = 200;
				$response['title'] = 'Provider registered';
				$response['msg'] = 'Provider added successfully.';
			}else{
				$response['status'] = 200;
				$response['title'] = 'Provider registered';
				$response['msg'] = 'Provider added successfully.';
			}
			echo json_encode($response);
		}
	}
?>