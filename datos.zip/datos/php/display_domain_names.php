<?php
	include_once "../includes/db_connection.php";

	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(md5(105) == $_POST['_token']){
			$response = array();
			$domains = array();

			$query = "SELECT p.provider_name, p.website_url, d.id, d.pro_acc_id, d.domain_name, d.email_accounts, d.expiry_date 
				FROM `domain_tbl` as d, `provider_account_tbl` as pa, `provider_tbl` as p
				WHERE d.pro_acc_id = pa.id AND pa.provider_id = p.id";

			$result = mysqli_query($link, $query) or die("Error: ".mysqli_error($link));

			if(mysqli_num_rows($result) > 0){
				while($row = mysqli_fetch_assoc($result)){
					array_push($domains, $row);
				}
				$response['status'] = 200;
				$response['domains'] = $domains;
			}else{
				$response['status'] = 201;
				$response['msg'] = "No domain names added yet to the system.";
			}
			echo json_encode($response);
		}
	}
?>