<?php
include_once "includes/check_access.php";
include_once "includes/header.php";
include_once "includes/sidebar.php";
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Provider Accounts &amp; Access Info 
            <small>Hostings, Domains Providers Accounts</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Provider Accounts</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-5">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Add Providers Account</h3>
                    </div><!-- /.box-header -->
                    <form id="provider-acc-frm">
                        <div class="box-body">
                            <div class="form-group">
                                <label>Select Provider</label>
                                <select name="provider" id="provider" class="form-control">
                                    <option value="0">Select Provider</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Account Username</label>
                                <input type="text" name="acc_username" id="acc_username" class="form-control" placeholder="Account Username">
                            </div>
                            <div class="form-group">
                                <label>Account Password</label>
                                <input type="text" name="acc_password" id="acc_password" class="form-control" placeholder="Account Password">
                            </div>
                            <div class="form-group">
                                <label>Security PIN (If Any)</label>
                                <input type="text" name="acc_pin" id="acc_pin" class="form-control" placeholder="Security PIN">
                            </div>
                        </div><!-- /.box-body -->
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary btn-flat">Submit</button>
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
            <div class="col-md-7">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Current Accounts</h3>
                    </div><!-- /.box-header -->                   
                    <div class="box-body">
                        <div class="table-responsive" id="account-list">
                                
                        </div>
                    </div><!-- /.box-body -->
                </div><!-- /.box -->
            </div>           
        </div>
        
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
    
    <!-- Edit user modal -->
    <div class="modal modal-default fade" id="edit-account-modal">
        <div class="modal-dialog" style="width: 30%">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">EDIT USER INFO</h4>
            </div>
            <form id="edit-account-frm">
            <div class="modal-body">   
                <input type="hidden" name="pa_id" id="pa_id">             
                <div class="form-group">
                    <label>Select Provider</label>
                    <select name="edit_provider" id="edit_provider" class="form-control">
                        <option value="0">Select Provider</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Account Username</label>
                    <input type="text" class="form-control" name="edit_acc_username" id="edit_acc_username" placeholder="Account Username">
                </div>
                <div class="form-group">
                    <label>Account Password</label>
                    <input type="text" class="form-control" name="edit_acc_password" id="edit_acc_password" placeholder="Account Password">
                </div>
                <div class="form-group">
                    <label>Security PIN (If Any)</label>
                    <input type="text" class="form-control" name="edit_acc_pin" id="edit_acc_pin" placeholder="Security PIN">
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary btn-flat"><i class="fa fa-save"></i> Save changes</button>
                </form>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
<?php
include_once "includes/footer.php";
?>
<script>
    $(document).ready(function(){
        $("#accounts-menu").addClass("active");
        $("#accounts-menu .treeview-menu li:eq(0)").addClass("active");
        load_provider_list('provider');
        load_provider_list('edit_provider');
        display_provider_accounts();
    });
</script>