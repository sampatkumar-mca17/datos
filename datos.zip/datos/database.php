<?php
include_once "includes/check_access.php";
include_once "includes/header.php";
include_once "includes/sidebar.php";
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Databases
            <small>All Databases &amp; Database Users.</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Databases</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-4">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Add Databases</h3>
                    </div><!-- /.box-header -->
                    <form id="db-frm">
                        <div class="box-body">                            
                            <div class="form-group">
                                <label>Select Server</label>
                                <select name="server" id="server" class="form-control">
                                    <option value="0">Select Server</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Database Host</label>
                                <input type="text" name="db_host" id="db_host" class="form-control" placeholder="Database Host">
                            </div>
                            <div class="form-group">
                                <label>Database User</label>
                                <input type="text" name="db_user" id="db_user" class="form-control" placeholder="Database User">
                            </div>                    
                            <div class="form-group">
                                <label>Database Password</label>
                                <input type="text" name="db_password" id="db_password" class="form-control" placeholder="Database Password">
                            </div>
                            <div class="form-group">
                                <label>Database Name</label>
                                <input type="text" name="db_name" id="db_name" class="form-control" placeholder="Database Name">
                            </div>                         
                        </div>     
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary btn-flat">Submit</button>
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
            <div class="col-md-8">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Current Databases</h3>
                    </div><!-- /.box-header -->                   
                    <div class="box-body" id="db-list">
                       
                    </div><!-- /.box-body -->
                </div><!-- /.box -->
            </div>
        </div>        
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
    
    <!-- Edit Servers Info -->
    <div class="modal modal-default fade" id="edit-db-modal">
        <div class="modal-dialog" style="width: 30%">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Update Database</h4>
            </div>
            <form id="edit-db-frm">
            <div class="modal-body">   
                <input type="hidden" name="db_id">             
                <div class="form-group">
                    <label>Select Server</label>
                    <select name="edit_server" id="edit_server" class="form-control">
                        <option value="0">Select Server</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Database Host</label>
                    <input type="text" name="edit_db_host" id="edit_db_host" class="form-control" placeholder="Database Host">
                </div>
                <div class="form-group">
                    <label>Database User</label>
                    <input type="text" name="edit_db_user" id="edit_db_user" class="form-control" placeholder="Database User">
                </div>                    
                <div class="form-group">
                    <label>Database Password</label>
                    <input type="text" name="edit_db_password" id="edit_db_password" class="form-control" placeholder="Database Password">
                </div>
                <div class="form-group">
                    <label>Database Name</label>
                    <input type="text" name="edit_db_name" id="edit_db_name" class="form-control" placeholder="Database Name">
                </div> 
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary btn-flat"><i class="fa fa-save"></i> Save changes</button>
                </form>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->

   
<?php
include_once "includes/footer.php";
?>
<script>
    $(document).ready(function(){
        $("#db-menu").addClass("active");
        $("#db-menu .treeview-menu li:eq(0)").addClass("active");
        load_servers("server");
        display_databases();
        load_servers("edit_server");
    });
</script>