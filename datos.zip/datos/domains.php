<?php
include_once "includes/check_access.php";
include_once "includes/header.php";
include_once "includes/sidebar.php";
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Domain Names
            <small> Domain Names &amp; Provider Info</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Domain Names</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-8">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Add Domain Names</h3>
                    </div><!-- /.box-header -->
                    <form id="dns-frm">
                        <div class="box-body">
                            <div class="row">                            
                                <div class="form-group col-md-4">
                                    <label>Select Provider</label>
                                    <select name="account" id="account" class="form-control">
                                        <option value="0">Select Provider</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Domain Name</label>
                                    <input type="text" name="dns" id="dns" class="form-control" placeholder="Domain Name">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Renewal Date</label>
                                    <input type="date" name="renewal" id="renewal" class="form-control">
                                </div>
                            </div>                            
                            <div class="form-group">
                                <h4>Email Accounts (If Any)</h4>
                            </div>
                            <div class="row" id="email-acc">                                
                                <div class="form-group col-md-5 email1">
                                    <input type="text" name="email" class="form-control" placeholder="Ex: support, contact">                                    
                                </div>
                                <div class="form-group col-md-5 email_pass1">
                                    <input type="text" name="em_acc_pass" class="form-control" placeholder="Email Account Password">                                    
                                </div>
                                <div class="form-group col-md-1">
                                    <button type="button" class="btn btn-default inc-email-acc" data-index="1"><i class="fa fa-plus"></i></button>
                                </div>
                                <div class="clearfix"></div>                                
                            </div>                                                     
                        </div>     
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary btn-flat">Submit</button>
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>            
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Current Domain Names</h3>
                    </div><!-- /.box-header -->
                    <div class="box-body" id="domain-list">
                            
                    </div>
                </div>
            </div>
        </div>        
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
    
    <!-- Edit Servers Info -->
    <div class="modal modal-default fade" id="edit-domain-email-modal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Update Email Address</h4>
            </div>
            <form id="edit-domain-email-frm">
            <div class="modal-body">   
                <input type="hidden" name="domain_id">
                <input type="hidden" name="index">
                <div class="form-group">
                    <label>New Email</label>
                    <input type="text" name="new_email" id="new_email" class="form-control" placeholder="New Email Address">
                </div> 
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary btn-flat"><i class="fa fa-save"></i> Save changes</button>
                </form>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->

    <div class="modal modal-default fade" id="edit-domain-email-pwd-modal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Update Email Account Password</h4>
            </div>
            <form id="edit-domain-email-pwd-frm">
            <div class="modal-body">   
                <input type="hidden" name="domain_id">
                <input type="hidden" name="index">
                <div class="form-group">
                    <label>New Password</label>
                    <input type="password" name="new_pwd" id="new_pwd" class="form-control" placeholder="New Password">
                </div> 
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary btn-flat"><i class="fa fa-save"></i> Save changes</button>
                </form>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->

      <div class="modal modal-default fade" id="add-domain-email-modal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Update Email Account Password</h4>
            </div>
            <form id="add-domain-email-frm">
            <div class="modal-body">   
                <input type="hidden" name="domain_id">
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="text" name="eml" id="eml" class="form-control" placeholder="Email Address">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="eml_pwd" id="eml_pwd" class="form-control" placeholder="Password">
                </div> 
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary btn-flat"><i class="fa fa-save"></i> Save changes</button>
                </form>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
<?php
include_once "includes/footer.php";
?>
<script>
    $(document).ready(function(){
        $("#domain-menu").addClass("active");
        $("#domain-menu .treeview-menu li:eq(0)").addClass("active");
        load_provider_account("account");
        display_domain_names();
    });
</script>