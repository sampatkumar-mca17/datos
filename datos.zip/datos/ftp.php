<?php
include_once "includes/check_access.php";
include_once "includes/header.php";
include_once "includes/sidebar.php";
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            FTP Account Details
            <small>FTP Accounts &amp; FTP Access Details.</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">FTP Accounts</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Add FTP Account</h3>
                    </div><!-- /.box-header -->
                    <form id="ftp-frm">
                        <div class="box-body">
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label>Select Server</label>
                                    <select name="server" id="server" class="form-control">
                                        <option value="0">Select Server</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label>FTP Host</label>
                                    <input type="text" name="ftp_host" id="ftp_host" class="form-control" placeholder="FTP Host">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>FTP Username</label>
                                    <input type="text" name="ftp_username" id="ftp_username" class="form-control" placeholder="FTP Username">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <label>FTP Password</label>
                                    <input type="text" name="ftp_password" id="ftp_password" class="form-control" placeholder="FTP Password">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>FTP Directory Path</label>
                                    <input type="text" name="path" id="path" class="form-control" placeholder="FTP Directory Path">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Select User</label>
                                    <select name="user" id="user" class="form-control">
                                        <option value="0">Select User</option>
                                    </select>
                                </div>
                            </div>                           
                        </div>     
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary btn-flat">Submit</button>
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Current FTP Accounts</h3>
                    </div><!-- /.box-header -->                   
                    <div class="box-body" id="ftp-list">
                       
                    </div><!-- /.box-body -->
                </div><!-- /.box -->
            </div> 
        </div>        
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
    
    <!-- Edit Servers Info -->
    <div class="modal modal-default fade" id="edit-ftp-modal">
        <div class="modal-dialog" style="width: 30%">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Update FTP Account</h4>
            </div>
            <form id="edit-ftp-frm">
            <div class="modal-body">   
                <input type="hidden" name="ftp_id">             
                <div class="form-group">
                    <label>Select Account</label>
                    <select name="edit_server" id="edit_server" class="form-control">
                        <option value="0">Select Server</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>FTP Host</label>
                    <input type="text" name="edit_ftp_host" id="edit_ftp_host" class="form-control" placeholder="FTP Host">
                </div>
                <div class="form-group">
                    <label>FTP Username</label>
                    <input type="text" name="edit_ftp_username" id="edit_ftp_username" class="form-control" placeholder="cPanel URL">
                </div>
                <div class="form-group">
                    <label>FTP Password</label>
                    <input type="text" name="edit_ftp_password" id="edit_ftp_password" class="form-control" placeholder="FTP Username">
                </div>
                <div class="form-group">
                    <label>FTP Directory Path</label>
                    <input type="text" name="edit_path" id="edit_path" class="form-control" placeholder="FTP Directory Path">
                </div>
                <div class="form-group">
                    <label>Select User</label>
                    <select name="edit_user" id="edit_user" class="form-control">
                        <option value="0">Select User</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary btn-flat"><i class="fa fa-save"></i> Save changes</button>
                </form>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->

   
<?php
include_once "includes/footer.php";
?>
<script>
    $(document).ready(function(){
        $("#ftp-menu").addClass("active");
        $("#ftp-menu .treeview-menu li:eq(0)").addClass("active");
        display_ftp_accounts();
        load_servers("server");
        load_users("user");
        load_servers("edit_server");
        load_users("edit_user");
    });
</script>