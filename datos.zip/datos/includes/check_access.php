<?php
    session_start();
    if($_SESSION['login_status'] != 'login')
        echo "<script>location.href='index.php'</script>";
?>