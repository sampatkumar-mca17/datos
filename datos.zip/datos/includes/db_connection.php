<?php
	
	// Accessing dbconfig file
	$db_config = parse_ini_file('dbconfig.ini', 1);

	$link = mysqli_connect($db_config['database']['host'], $db_config['database']['user'], $db_config['database']['password'], $db_config['database']['dbname']);

	if(!$link)
		die('Error: '.mysqli_connect_error());

?>