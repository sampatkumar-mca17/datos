<!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="dist/img/datos_small.png" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><?=$_SESSION['user']?></p>
              <a href="#"><i class="fa fa-circle text-success"></i> 
                <?php
                if($_SESSION['is_admin'] == 1){
                  echo "Administrator";
                }else{
                  echo "Team Member";
                }
                ?>
              </a>
            </div>
          </div>          
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>           
            <li class="treeview" id="users-menu">
              <a href="users.php">
                <i class="fa fa-users"></i>
                <span>Add Users</span>&nbsp;
                <span class="label label-primary" id="admin-cnt"></span>&nbsp;<span class="label label-warning" id="team-cnt"></span>
              </a>
            </li>
            <li class="treeview" id="providers-menu"><a href="#">
              <i class="fa fa-briefcase"></i>
              <span>Providers</span>
              <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="providers.php"><i class="fa fa-circle-o"></i> Add Providers</a></li>
                <li><a href="reports.php?of=providers"><i class="fa fa-circle-o"></i> Reports</a></li>        
              </ul>
            </li>
            <li class="treeview" id="accounts-menu"><a href="#">
              <i class="fa fa-cube"></i>
              <span>Accounts</span>
              <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="accounts.php"><i class="fa fa-circle-o"></i> Add Accounts</a></li>
                <li><a href="reports.php?of=accounts"><i class="fa fa-circle-o"></i> Reports</a></li>        
              </ul>
            </li>
            <li class="treeview" id="servers-menu"><a href="#">
              <i class="fa fa-server"></i>
              <span>Servers</span>
              <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="servers.php"><i class="fa fa-circle-o"></i> Add Servers</a></li>
                <li><a href="reports.php?of=servers"><i class="fa fa-circle-o"></i> Reports</a></li>        
              </ul>
            </li>
            <li class="treeview" id="domain-menu"><a href="#">
              <i class="fa fa-globe"></i>
              <span>Domain Names</span>
              <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="domains.php"><i class="fa fa-circle-o"></i> Add Domain Name</a></li>
                <li><a href="reports.php?of=domains"><i class="fa fa-circle-o"></i> Reports</a></li>        
              </ul>
            </li>
            <li class="treeview" id="ftp-menu">
              <a href="#">
                <i class="fa fa-folder-open-o"></i>
                <span>FTP Accounts</span> 
                <i class="fa fa-angle-left pull-right"></i>             
              </a>
              <ul class="treeview-menu">
                <li><a href="ftp.php"><i class="fa fa-circle-o"></i> Add FTP Accounts</a></li>
                <li><a href="reports.php?of=ftp"><i class="fa fa-circle-o"></i> Reports</a></li>        
              </ul>
            </li>
            <li class="treeview" id="db-menu">
              <a href="#">
                <i class="fa fa-database"></i>
                <span>Databases</span> 
                <i class="fa fa-angle-left pull-right"></i>             
              </a>
              <ul class="treeview-menu">
                <li><a href="database.php"><i class="fa fa-circle-o"></i> Add Database</a></li>
                <li><a href="reports.php?of=database"><i class="fa fa-circle-o"></i> Reports</a></li>        
              </ul>
            </li>
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>