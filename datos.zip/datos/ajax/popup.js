function popup(type, title, msg)
{

	if(type === 'danger')
		$(".alerts").addClass("callout-danger");
	else if(type === 'success')
		$(".alerts").addClass("callout-success");
	else if(type === 'warning')
		$(".alerts").addClass("callout-warning");
	else if(type === 'info')
		$(".alerts").addClass("callout-info");

	$(".alerts h4").html(title);
	$(".alerts p").html(msg);

	$(".alerts").animate({'left': '5%'}, 1500);
	$(".alerts").animate({'left': '0%'}, 1500);

	setTimeout(function(){
		$(".alerts").animate({'left': '-1000px'}, 1500);
	}, 4000);

	setTimeout(function(){
	if(type === 'danger')
		$(".alerts").removeClass("callout-danger");
	else if(type === 'success')
		$(".alerts").removeClass("callout-success");
	else if(type === 'warning')
		$(".alerts").removeClass("callout-warning");
	else if(type === 'info')
		$(".alerts").removeClass("callout-info");
	}, 5000);
}